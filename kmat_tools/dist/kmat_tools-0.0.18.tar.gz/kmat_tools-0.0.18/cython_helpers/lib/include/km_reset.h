#ifndef KM_RESET_H
#define KM_RESET_H

void km_reset();

#endif /* RESET_OPTIND_H */
